package com.atilsamancioglu.kotlinfirebaseinsta.model

data class Post (val email: String, val comment : String, val downloadUrl : String )